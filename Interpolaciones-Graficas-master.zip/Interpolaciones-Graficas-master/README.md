# Interpolaciones-Graficas
Graficas de Lagrange, Bezier, BSpline

Instalar scipy:

python -m pip install --user numpy scipy matplotlib ipython jupyter pandas sympy nose

Instalar matplotlib:

python -m pip install -U pip

python -m pip install -U matplotlib

Instalar sympy:

sudo pip install sympy

Instalar numpy:

pip install numpy

Ejecutar programas:

python Bezier.py

python BSpline.py

python Lagrange.py
